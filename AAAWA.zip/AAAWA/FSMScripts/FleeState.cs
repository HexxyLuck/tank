﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Class <c>FleeState</c> inherits from <c>BaseState</c>, manages behaviour for StateEnter, StateUpdate and StateExit
/// </summary>
public class FleeState : BaseState
{
    private EnemyShip enShip;

    /// <summary>
    /// Constructur sets the state. 
    /// </summary>
    /// <param name="enShip">Reference to EnemyShip script to call functions</param>
    public FleeState(EnemyShip enShip)
    {
        this.enShip = enShip;
    }

    public override Type StateEnter()
    {
        enShip.stats["fleeState"] = true;

        enShip.GetComponent<Rigidbody>().isKinematic = false;

        if (enShip.shootParticles.isPlaying)
        {
            enShip.shootParticles.Stop();
        }

        if (enShip.light.color != Color.blue)
        {
            enShip.light.color = Color.blue;
        }
        return null;
    }

    public override Type StateExit()
    {
        enShip.stats["fleeState"] = false;
        return null;
    }

    public override Type StateUpdate()
    {
        enShip.FleeTarget();

        foreach (var item in enShip.rules.GetRules)
        {

            if (item.CheckRule(enShip.stats) != null)
            {
                Debug.Log("rule");
                return item.CheckRule(enShip.stats);



            }
            
        }


        return null;


    }

}