﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Class <c>AttackState</c> inherits from <c>BaseState</c>, manages behaviour for StateEnter, StateUpdate and StateExit
/// </summary>
public class AttackState : BaseState
{
    private EnemyShip enShip;
    float time = 0;

    /// <summary>
    /// Constructur sets the state. 
    /// </summary>
    /// <param name="enShip">Reference to EnemyShip script to call functions</param>
    public AttackState(EnemyShip enShip)
    {
        this.enShip = enShip;
    }

    public override Type StateEnter()
    {
        enShip.stats["attackState"] = true;
        enShip.GetComponent<Rigidbody>().isKinematic = true;

        if (!enShip.shootParticles.isPlaying)
        {
            enShip.shootParticles.Play();
        }

        if (enShip.light.color != Color.red)
        {
            enShip.light.color = Color.red;
        }
        return null;
    }

    public override Type StateExit()
    {
        enShip.stats["attackState"] = false;
        time = 0;
        return null;
    }

    public override Type StateUpdate()
    {
        enShip.AttackTarget();
        time += Time.deltaTime;

        if (time > 1f)
        {

            if (enShip.stats["lowHealth"] == true)
            {

                return typeof(FleeState);

            }



            if (enShip.stats["targetReached"] == true)
            {

                return typeof(AttackState);

            }

            else
            {

                return typeof(SearchState);



            }

        }

        return null;  
    }
}
