﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Class <c>SearchState</c> inherits from <c>BaseState</c>, manages behaviour for StateEnter, StateUpdate and StateExit
/// </summary>
public class SearchState : BaseState
{
    private EnemyShip enShip;

    /// <summary>
    /// Constructur sets the state. 
    /// </summary>
    /// <param name="enShip">Reference to EnemyShip script to call functions</param>
    public SearchState(EnemyShip enShip) 
    {
        this.enShip = enShip;
    }

    public override Type StateEnter()
    {
        enShip.stats["searchState"] = true;

        enShip.GetComponent<Rigidbody>().isKinematic = false;

        if (enShip.shootParticles.isPlaying)
        {
            enShip.shootParticles.Stop();
        }

        if (enShip.light.color != Color.white)
        {
            enShip.light.color = Color.white;
        }
        return null;
    }

    public override Type StateExit()
    {
        enShip.stats["searchState"] = false;
        return null;
    }

    public override Type StateUpdate()
    {
        enShip.SearchTarget();
        foreach (var item in enShip.rules.GetRules)
        {

            if (item.CheckRule(enShip.stats) != null)

            {

                return item.CheckRule(enShip.stats);



            }

        }


        return null;


    }
}
