﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Class <c>ChaseState</c> inherits from <c>BaseState</c>, manages behaviour for StateEnter, StateUpdate and StateExit
/// </summary>
public class ChaseState : BaseState
{
    private EnemyShip enShip;

    /// <summary>
    /// Constructur sets the state. 
    /// </summary>
    /// <param name="enShip">Reference to EnemyShip script to call functions</param>
    public ChaseState(EnemyShip enShip)
    {
        this.enShip = enShip;
    }

    public override Type StateEnter()
    {
        enShip.stats["chaseState"] = true;

        enShip.GetComponent<Rigidbody>().isKinematic = false;

        if (enShip.shootParticles.isPlaying)
        {
            enShip.shootParticles.Stop();
        }

        if (enShip.light.color != Color.yellow)
        {
            enShip.light.color = Color.yellow;
        }
        return null;
    }

    public override Type StateExit()
    {
        enShip.stats["chaseState"] = false;
        return null;
    }

    public override Type StateUpdate()
    {
        enShip.ChaseTarget();
        foreach (var item in enShip.rules.GetRules)
        {

            if (item.CheckRule(enShip.stats) != null)
            {

                return item.CheckRule(enShip.stats);



            }

        }


        return null;


    }
}
