﻿using System;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;

/// <summary>
/// Class <c>EnemyShip</c> contains functions for the ship.
/// </summary>
public class EnemyShip : MonoBehaviour
{
    public AStar _aStar;
    public GameObject targetGameObject, randomNodeGO;
    public ParticleSystem shootParticles;
    List<Node> path;
    float time = 0;
    private Vector3 velocitySearch;
    private Vector3 velocityChase;
    private Vector3 velocityFlee;
    private Vector3 velocityRot;
    private Vector3 velocityCentreSearch;
    private Vector3 velocityCentreChase;
    private Vector3 velocityCentreFlee;
    Vector3 centrePosNew = Vector3.zero;
    Vector3 centrePosHolder;
    [HideInInspector]
    public Light light;
    Node randomNode;
    bool randomNodeFound = true;

    public Dictionary<string, bool> stats = new Dictionary<string, bool>();

    public Rules rules = new Rules();

    public bool lowHealth;

    private void Awake()
    {
        InitializeStateMachine();
        light = GetComponentInChildren<Light>();
    }
    private void Start()
    {
        InitialiseStats();

        InitialiseRules();
    }

    /// <summary>
    /// Initialises finite state machine, setting the states.
    /// </summary>
    private void InitializeStateMachine()
    {
        Dictionary<Type, BaseState> states = new Dictionary<Type, BaseState>();

        states.Add(typeof(FleeState), new FleeState(this));
        states.Add(typeof(SearchState), new SearchState(this));
        states.Add(typeof(ChaseState), new ChaseState(this));
        states.Add(typeof(AttackState), new AttackState(this));

        GetComponent<StateMachine>().SetStates(states);
    }

    /// <summary>
    /// Function is called for when ship should flee. Flee to a random node (point) in grid plane.
    /// </summary>
    public void FleeTarget()
    {
        if (randomNodeFound || !randomNode.traversable)
        {
            randomNodeFound = false;
            randomNode = _aStar.NodePositionInGrid(new Vector3(Random.Range(-5, 5), 0, Random.Range(-5, 5)));

            if (randomNode.traversable)
            {
                randomNodeGO.transform.position = randomNode.nodePos;
            }
        }
        else
        {
            //Request Path
            path = _aStar.RequestPath(this.gameObject, randomNodeGO);
            if (path != null && path.Count > 3)
            {
                Vector3 centrePos = Vector3.SmoothDamp(centrePosHolder, FindCentre(path), ref velocityCentreFlee, 0.17f);

                Vector3 goTo = Vector3.SmoothDamp(transform.position, centrePos, ref velocityFlee, 0.06f);

                transform.position = Vector3.MoveTowards(transform.position, goTo, 0.6f);

                transform.LookAt(Vector3.SmoothDamp(transform.position, centrePos, ref velocityRot, 1f));
            }

            if (Vector3.Distance(transform.position, randomNode.nodePos) < 1)
            {
                randomNodeFound = true;
            }
        }
        CheckTargetSpotted();
        CheckTargetReached();
    }

    /// <summary>
    /// Function is called for when ship should randomly search. Search to a random node (point) in grid plane.
    /// </summary>
    public void SearchTarget()
    {
        if (randomNodeFound || !randomNode.traversable)
        {
            randomNodeFound = false;
            randomNode = _aStar.NodePositionInGrid(new Vector3(Random.Range(-5, 5), 0, Random.Range(-5, 5)));

            if (randomNode.traversable)
            {
                randomNodeGO.transform.position = randomNode.nodePos;
            }
        }
        else
        {
            //Request Path
            path = _aStar.RequestPath(this.gameObject, randomNodeGO);
            if (path != null && path.Count > 3)
            {
                Vector3 centrePos = Vector3.SmoothDamp(centrePosHolder, FindCentre(path), ref velocityCentreSearch, 0.3f);

                Vector3 goTo = Vector3.SmoothDamp(transform.position, centrePos, ref velocitySearch, 0.1f);

                transform.position = Vector3.MoveTowards(transform.position, goTo, 1f);

                transform.LookAt(Vector3.SmoothDamp(transform.position, centrePos, ref velocityRot, 1f));

            }

            if(Vector3.Distance(transform.position, randomNode.nodePos) < 1)
            {
                randomNodeFound = true;
            }
        }
        CheckTargetSpotted();
        CheckTargetReached();
    }

    /// <summary>
    /// Function is called for when ship should chase target. 
    /// </summary>
    public void ChaseTarget()
    {
        //Request Path
        path = _aStar.RequestPath(this.gameObject, targetGameObject);
        if (path != null && path.Count > 3)
        {
            Vector3 centrePos = Vector3.SmoothDamp(centrePosHolder, FindCentre(path), ref velocityCentreChase, 0.3f);

            Vector3 goTo = Vector3.SmoothDamp(transform.position, centrePos, ref velocityChase, 0.1f);

            transform.position = Vector3.MoveTowards(transform.position, goTo, 1f);

            transform.LookAt(Vector3.SmoothDamp(transform.position, centrePos, ref velocityRot, 1f));

        }
        CheckTargetSpotted();
        CheckTargetReached();
    }


    /// <summary>
    /// Function is called for when ship should attach target. 
    /// </summary>
    public void AttackTarget()
    {
        transform.LookAt(new Vector3(targetGameObject.transform.position.x, 0, targetGameObject.transform.position.z));
        CheckTargetSpotted();
        CheckTargetReached();
    }

    public void CheckTargetSpotted()
    {
        if (Vector3.Distance(transform.position, targetGameObject.transform.position) < 2.65f)

        {

            stats["targetSpotted"] = true;

        }

        else

        {

            stats["targetSpotted"] = false;

        }
    }

    public void CheckTargetReached()
    {
        if (Vector3.Distance(transform.position, targetGameObject.transform.position) < 1.5f)

        {

            stats["targetReached"] = true;

        }

        else

        {

            stats["targetReached"] = false;

        }
    }

    Vector3 FindCentre(List<Node> _path)
    {
        float x = 0;
        float y = 0;
        float z = 0;

        centrePosHolder = centrePosNew;

        for (int i = 0; i < 4; i++)
        {
            x += _path[i].nodePos.x;
            y += _path[i].nodePos.y;
            z += _path[i].nodePos.z;

        }

        x = x / 4;
        y = y / 4;
        z = z / 4;

        centrePosNew = new Vector3(x, y, z);

        return centrePosNew;
    }
    void InitialiseStats()

    {

        stats.Add("lowHealth", lowHealth);

        stats.Add("targetSpotted", false);

        stats.Add("targetReached", false);

        stats.Add("fleeState", false);

        stats.Add("chaseState", false);

        stats.Add("searchState", false);

        stats.Add("attackState", false);

    }
    void InitialiseRules()
    {

        rules.AddRule(new Rule("attackState", "lowHealth", typeof(FleeState), Rule.Predicate.And));

        rules.AddRule(new Rule("chaseState", "lowHealth", typeof(FleeState), Rule.Predicate.And));

        rules.AddRule(new Rule("searchState", "targetSpotted", typeof(ChaseState), Rule.Predicate.And));

        rules.AddRule(new Rule("searchState", "targetSpotted", typeof(SearchState), Rule.Predicate.nAnd));

        rules.AddRule(new Rule("chaseState", "targetReached", typeof(AttackState), Rule.Predicate.And));

    }
}
